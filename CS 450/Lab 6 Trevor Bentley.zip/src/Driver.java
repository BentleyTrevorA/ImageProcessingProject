import javax.imageio.ImageIO;

public class Driver
{
    public static void main(String[] args) {
        HW6 hw = new HW6();
        CS450.run(hw);

//        for (String name : ImageIO.getReaderFormatNames()) {
//            System.out.println(name);
//        }
    }
}
