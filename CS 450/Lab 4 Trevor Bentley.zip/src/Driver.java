import javax.imageio.ImageIO;

public class Driver
{
    public static void main(String[] args) {
        HW4 hw = new HW4();
        CS450.run(hw);

//        for (String name : ImageIO.getReaderFormatNames()) {
//            System.out.println(name);
//        }
    }
}
