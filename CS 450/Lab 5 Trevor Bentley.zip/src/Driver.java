import javax.imageio.ImageIO;

public class Driver
{
    public static void main(String[] args) {
        HW5 hw = new HW5();
        CS450.run(hw);

//        for (String name : ImageIO.getReaderFormatNames()) {
//            System.out.println(name);
//        }
    }
}
